#import pandas as pd
from collections import Counter
from string import ascii_lowercase as lowers
from kryptos_gen import decrypt, ciphertxt, somewords, reverse, expected

for i in lowers: #oooo
    print(i, Counter(decrypt(ciphertxt, "ooooo"+ i)))

print(expected)

#df = pd.read_csv("keyword-frequency.csv")
#print(df.head())

#df = df.sort_values(["frequency"])
#df = df[df["frequency"].str.startswith("{'E': 9, 'A':")]

#print(df.tail())

